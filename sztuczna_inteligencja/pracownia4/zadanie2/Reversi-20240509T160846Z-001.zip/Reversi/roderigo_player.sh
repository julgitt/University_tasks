#!/bin/bash

pypy3 roderigo.py 3
